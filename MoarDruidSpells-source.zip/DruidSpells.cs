using System;
using System.Collections.Generic;
using HarmonyLib;
using UnityEngine;
using UnityEngine.SceneManagement;

namespace MoarDruidSpells
{
    /// <summary>
    /// Main mod class - registers spell definitions for Druid class.
    /// Spells are based on EverQuest druid spell lines (levels 1-50) adapted for Erenshor (cap 35).
    /// </summary>
    public static class DruidSpells
    {
        /// <summary>
        /// Register all custom Druid spells here.
        /// Called at plugin startup before databases are loaded.
        ///
        /// EQ Druid Spell Lines to implement:
        /// - Healing (direct heals, HoTs)
        /// - Nature's Fire (fire-based DD)
        /// - Stinging Swarm (magic DoT)
        /// - Drones of Doom (poison DoT)
        /// - Skin buffs (AC buffs)
        /// - Regeneration (HP regen buffs)
        /// - Movement (Spirit of Wolf line) - already in SpiritOfTheWoof
        /// - Snare/Root (Snare line, Ensnare, Root)
        /// - Strength of Nature (STR buffs)
        /// - Shield of Thorns (damage shields)
        /// - Resist buffs (various resist lines)
        /// </summary>
        public static void RegisterAllSpells()
        {
            // ==================== SNARE LINE ====================

            // Snare (Level 5) - Pure movement debuff
            SpellRegistry.RegisterSpell(new SpellRegistry.SpellDefinition
            {
                Id = "mds_snare",
                SpellName = "Snare",
                Description = "Reduces target's movement speed significantly.",
                IconFileName = "Ensnare_64x64.png",
                Type = Spell.SpellType.StatusEffect,
                Line = Spell.SpellLine.Global_Other_Debuff,
                DamageType = GameData.DamageType.Physical,
                RequiredLevel = 5,
                ManaCost = 50,
                CastTime = 120f,  // 2.0 seconds (60 ticks = 1 sec)
                Cooldown = 6f,
                MovementSpeed = -2.0f,
                DurationTicks = 30,  // 3 minutes
                Aggro = 40,
                UnstableDuration = false,
                ChargeFXIndex = 7,
                ResolveFXIndex = 7,
                StatusMessagePlayer = "You have been snared!",
                StatusMessageNPC = "has been snared!"
            });

            // Ensnare (Level 25) - Stronger snare
            SpellRegistry.RegisterSpell(new SpellRegistry.SpellDefinition
            {
                Id = "mds_ensnare",
                SpellName = "Ensnare",
                Description = "Greatly reduces target's movement speed.",
                IconFileName = "Ensnare_64x64.png",
                Type = Spell.SpellType.StatusEffect,
                Line = Spell.SpellLine.Global_Other_Debuff,
                DamageType = GameData.DamageType.Physical,
                RequiredLevel = 25,
                ManaCost = 200,
                CastTime = 120f,
                Cooldown = 6f,
                MovementSpeed = -4.0f,
                DurationTicks = 60,  // 6 minutes
                Aggro = 60,
                UnstableDuration = false,
                ChargeFXIndex = 7,
                ResolveFXIndex = 7,
                StatusMessagePlayer = "You have been ensnared!",
                StatusMessageNPC = "has been ensnared!"
            });

            // ==================== ROOT LINE ====================

            // Entangle (Level 20) - Root upgrade
            SpellRegistry.RegisterSpell(new SpellRegistry.SpellDefinition
            {
                Id = "mds_entangle",
                SpellName = "Entangle",
                Description = "Roots target in place with grasping vines, dealing damage.",
                IconFileName = "Entangle_64x64.png",
                Type = Spell.SpellType.StatusEffect,
                Line = Spell.SpellLine.Global_Root,
                DamageType = GameData.DamageType.Poison,
                RequiredLevel = 20,
                ManaCost = 150,
                CastTime = 150f,  // 2.5 seconds
                Cooldown = 6f,
                TargetDamage = 200,  // Damage per tick while rooted
                RootTarget = true,
                DurationTicks = 10,  // 60 seconds
                Aggro = 80,
                UnstableDuration = true,
                BreakOnDamage = false,
                ChargeFXIndex = 7,
                ResolveFXIndex = 7,
                StatusMessagePlayer = "You have been entangled!",
                StatusMessageNPC = "has been entangled!"
            });

            // ==================== DOT LINE ====================

            // Immolate (Level 13) - Elemental DoT + AC debuff
            SpellRegistry.RegisterSpell(new SpellRegistry.SpellDefinition
            {
                Id = "mds_immolate",
                SpellName = "Immolate",
                Description = "Engulfs target in flames, dealing damage over time and weakening their armor.",
                IconFileName = "Immolate_64x64.png",
                Type = Spell.SpellType.StatusEffect,
                Line = Spell.SpellLine.Dru_Element_DOT,
                DamageType = GameData.DamageType.Elemental,
                RequiredLevel = 13,
                ManaCost = 150,
                CastTime = 90f,  // 1.5 seconds
                Cooldown = 0f,
                TargetDamage = 100,  // DoT damage per tick (uses TargetDamage, not HP)
                AC = -15,   // AC debuff
                DurationTicks = 6,  // 36 seconds
                Aggro = 60,
                ChargeFXIndex = 7,
                ResolveFXIndex = 7,
                StatusMessagePlayer = "You are immolated!",
                StatusMessageNPC = "is immolated!"
            });

            // Drifting Death (Level 27) - Poison DoT
            SpellRegistry.RegisterSpell(new SpellRegistry.SpellDefinition
            {
                Id = "mds_drifting_death",
                SpellName = "Drifting Death",
                Description = "A cloud of toxic spores surrounds the target, dealing poison damage.",
                IconFileName = "DriftingDeath_64x64.png",
                Type = Spell.SpellType.StatusEffect,
                Line = Spell.SpellLine.Dru_Poison_DOT,
                DamageType = GameData.DamageType.Poison,
                RequiredLevel = 27,
                ManaCost = 500,
                CastTime = 90f,  // 1.5 seconds
                Cooldown = 0f,
                TargetDamage = 700,  // DoT damage per tick (uses TargetDamage, not HP)
                DurationTicks = 4,  // ~21 seconds (3.5 ticks rounded)
                Aggro = 60,
                ChargeFXIndex = 7,
                ResolveFXIndex = 7,
                StatusMessagePlayer = "You are surrounded by toxic spores!",
                StatusMessageNPC = "is surrounded by toxic spores!"
            });

            // ==================== DIRECT DAMAGE LINE ====================

            // Burst of Flame (Level 22) - Fire nuke
            SpellRegistry.RegisterSpell(new SpellRegistry.SpellDefinition
            {
                Id = "mds_burst_of_flame",
                SpellName = "Burst of Flame",
                Description = "Unleashes a burst of fire at your target.",
                IconFileName = "BurstOfFlame_64x64.png",
                Type = Spell.SpellType.Damage,
                Line = Spell.SpellLine.Direct_Damage,
                DamageType = GameData.DamageType.Elemental,
                RequiredLevel = 22,
                ManaCost = 750,
                CastTime = 180f,  // 3.0 seconds
                Cooldown = 6f,
                TargetDamage = 1600,  // Direct damage uses TargetDamage, not HP
                Aggro = 250,
                ChargeFXIndex = 7,
                ResolveFXIndex = 7
            });

            // Inferno (Level 33) - Top tier fire nuke
            SpellRegistry.RegisterSpell(new SpellRegistry.SpellDefinition
            {
                Id = "mds_inferno",
                SpellName = "Inferno",
                Description = "Calls down a devastating inferno upon your target.",
                IconFileName = "Inferno_64x64.png",
                Type = Spell.SpellType.Damage,
                Line = Spell.SpellLine.Direct_Damage,
                DamageType = GameData.DamageType.Elemental,
                RequiredLevel = 33,
                ManaCost = 1000,
                CastTime = 198f,  // 3.3 seconds
                Cooldown = 6f,
                TargetDamage = 3400,  // Direct damage uses TargetDamage, not HP
                Aggro = 500,
                ChargeFXIndex = 7,
                ResolveFXIndex = 7
            });

            // ==================== STR + RESIST BUFF LINE ====================

            // Strength of Earth (Level 10) - STR + all resists
            SpellRegistry.RegisterSpell(new SpellRegistry.SpellDefinition
            {
                Id = "mds_strength_of_earth",
                SpellName = "Strength of Earth",
                Description = "Infuses target with the strength of the earth, increasing strength and resistances.",
                IconFileName = "Strength_64x64.png",
                Type = Spell.SpellType.Beneficial,
                Line = Spell.SpellLine.Global_Resists,  // Uses resist line so it stacks with other buff types
                DamageType = GameData.DamageType.Physical,
                RequiredLevel = 10,
                ManaCost = 75,
                CastTime = 120f,  // 2.0 seconds
                Cooldown = 2f,
                ChargeFXIndex = 7,
                ResolveFXIndex = 7,
                Str = 20,
                MR = 10,
                ER = 10,
                PR = 10,
                VR = 10,
                DurationTicks = 150,  // 900 seconds (15 min)
                Aggro = 0,
                StatusMessagePlayer = "feel the strength of the earth.",  // Game prepends "You "
                StatusMessageNPC = "is imbued with earthen strength."
            });

            // Strength of Stone (Level 26) - STR + all resists upgrade
            SpellRegistry.RegisterSpell(new SpellRegistry.SpellDefinition
            {
                Id = "mds_strength_of_stone",
                SpellName = "Strength of Stone",
                Description = "Infuses target with the unyielding strength of stone.",
                IconFileName = "Strength_64x64.png",
                Type = Spell.SpellType.Beneficial,
                Line = Spell.SpellLine.Global_Resists,  // Uses resist line so it stacks with other buff types
                DamageType = GameData.DamageType.Physical,
                RequiredLevel = 26,
                ManaCost = 150,
                CastTime = 120f,
                Cooldown = 2f,
                ChargeFXIndex = 7,
                ResolveFXIndex = 7,
                Str = 30,
                MR = 20,
                ER = 20,
                PR = 20,
                VR = 20,
                DurationTicks = 150,
                Aggro = 0,
                StatusMessagePlayer = "feel the strength of stone.",  // Game prepends "You "
                StatusMessageNPC = "is imbued with stone's strength."
            });

            // Storm Strength (Level 31) - Top tier STR + all resists
            SpellRegistry.RegisterSpell(new SpellRegistry.SpellDefinition
            {
                Id = "mds_storm_strength",
                SpellName = "Storm Strength",
                Description = "Channels the raw power of nature's fury into the target.",
                IconFileName = "Strength_64x64.png",
                Type = Spell.SpellType.Beneficial,
                Line = Spell.SpellLine.Global_Resists,  // Uses resist line so it stacks with other buff types
                DamageType = GameData.DamageType.Physical,
                RequiredLevel = 31,
                ManaCost = 200,
                CastTime = 120f,
                Cooldown = 2f,
                ChargeFXIndex = 7,
                ResolveFXIndex = 7,
                Str = 40,
                MR = 30,
                ER = 30,
                PR = 30,
                VR = 30,
                DurationTicks = 150,
                Aggro = 0,
                StatusMessagePlayer = "surge with storm strength!",  // Game prepends "You "
                StatusMessageNPC = "surges with storm strength!"
            });

            // ==================== SKIN BUFF LINE ====================

            // Skin Like Nature (Level 34) - AC + End + HoT
            SpellRegistry.RegisterSpell(new SpellRegistry.SpellDefinition
            {
                Id = "mds_skin_like_nature",
                SpellName = "Skin Like Nature",
                Description = "Grants the target bark-like skin and natural regeneration.",
                IconFileName = "SkinLikeNature_64x64.png",
                Type = Spell.SpellType.Beneficial,
                Line = Spell.SpellLine.Global_Buff,  // Global_Buff allows higher-power regens to overwrite
                DamageType = GameData.DamageType.Physical,
                RequiredLevel = 34,
                ManaCost = 500,
                CastTime = 120f,
                Cooldown = 2f,
                ChargeFXIndex = 7,
                ResolveFXIndex = 0,  // No resolve visual - WornEffect should be silent like equipment
                AC = 125,
                End = 50,
                TargetHealing = 60,  // HoT: ~10 HP/sec (60 HP per 6-sec tick)
                WornEffect = true,   // Treats regen like equipment - no wisdom scaling, no combat log spam
                DurationTicks = 300,  // 1800 seconds (30 min)
                Aggro = 0,
                StatusMessagePlayer = "feel your skin harden like bark.",  // Game prepends "You "
                StatusMessageNPC = "'s skin hardens like bark."
            });

            // ==================== BIND & RECALL LINE ====================

            // Bind (Level 5) - Sets respawn location
            SpellRegistry.RegisterSpell(new SpellRegistry.SpellDefinition
            {
                Id = "mds_bind",
                SpellName = "Bind",
                Description = "Binds your spirit to your current location, setting it as your respawn point.",
                IconFileName = "Bind_64x64.png",  // Fixed: was using wrong icon
                Type = Spell.SpellType.Misc,
                Line = Spell.SpellLine.Generic,
                DamageType = GameData.DamageType.Magic,
                RequiredLevel = 5,
                ManaCost = 100,
                CastTime = 480f,  // 8.0 seconds (60 ticks = 1 sec)
                Cooldown = 8f,
                SelfOnly = true,
                SpellRange = 100f,  // Fixed: 0f caused "target too far away" error
                ChargeFXIndex = 7,
                ResolveFXIndex = 7,
                StatusMessagePlayer = "feel your spirit bind to this location.",
                StatusMessageNPC = ""
            });

            // Recall (Level 9) - Teleport to respawn location
            SpellRegistry.RegisterSpell(new SpellRegistry.SpellDefinition
            {
                Id = "mds_recall",
                SpellName = "Recall",
                Description = "Transports you to your bound respawn location.",
                IconFileName = "Recall_64x64.png",
                Type = Spell.SpellType.Misc,
                Line = Spell.SpellLine.Generic,
                DamageType = GameData.DamageType.Magic,
                RequiredLevel = 9,
                ManaCost = 150,
                CastTime = 480f,  // 8.0 seconds (60 ticks = 1 sec)
                Cooldown = 8f,
                SelfOnly = true,
                SpellRange = 100f,  // Fixed: 0f caused "target too far away" error
                ChargeFXIndex = 7,
                ResolveFXIndex = 7,
                StatusMessagePlayer = "feel yourself pulled toward your bind point.",
                StatusMessageNPC = ""
            });

            // ==================== SPIRIT OF THE WOLF LINE ====================

            // Helper function to get SoW icon based on config
            Func<string> getSoWIcon = () => Plugin.UseClassicSoWIcon?.Value == true
                ? "SoW_orig_64x64.png"
                : "SoW_64x64.png";

            // Lesser Spirit of the Wolf (Level 5) - Entry level movement speed buff
            SpellRegistry.RegisterSpell(new SpellRegistry.SpellDefinition
            {
                Id = "mds_lesser_spirit_of_the_wolf",
                SpellName = "Lesser Spirit of the Wolf",
                Description = "Calls upon a lesser wolf spirit to increase movement speed.",
                GetIconFileName = getSoWIcon,
                Type = Spell.SpellType.Beneficial,
                Line = Spell.SpellLine.Global_Move,
                RequiredLevel = 5,
                ManaCost = 50,
                CastTime = 360f, // 6 seconds (60 ticks = 1 second)
                DurationTicks = 150, // 15 minutes (1 tick = 6 seconds)
                MovementSpeed = 1.5f,
                SelfOnly = false,
                SpellRange = 100f,
                ChargeFXIndex = 7,
                ResolveFXIndex = 7,
                StatusMessagePlayer = "You feel a lesser wolf spirit guiding your steps.",
                StatusMessageNPC = " feels a lesser wolf spirit.",
                GetClass = () => GameData.ClassDB?.Druid
            });

            // Spirit of the Wolf (Level 15) - Standard movement speed buff
            SpellRegistry.RegisterSpell(new SpellRegistry.SpellDefinition
            {
                Id = "mds_spirit_of_the_wolf",
                SpellName = "Spirit of the Wolf",
                Description = "Calls upon the spirit of the wolf to increase movement speed.",
                GetIconFileName = getSoWIcon,
                Type = Spell.SpellType.Beneficial,
                Line = Spell.SpellLine.Global_Move,
                RequiredLevel = 15,
                ManaCost = 100,
                CastTime = 600f, // 10 seconds (60 ticks = 1 second)
                DurationTicks = 300, // 30 minutes (1 tick = 6 seconds)
                MovementSpeed = 2.5f,
                SelfOnly = false,
                SpellRange = 100f,
                ChargeFXIndex = 7,
                ResolveFXIndex = 7,
                StatusMessagePlayer = "You feel the spirit of the wolf coursing through you.",
                StatusMessageNPC = " feels the spirit of the wolf.",
                GetClass = () => GameData.ClassDB?.Druid
            });

            // Spirit of the Greater Wolf (Level 25) - Enhanced movement speed buff
            SpellRegistry.RegisterSpell(new SpellRegistry.SpellDefinition
            {
                Id = "mds_spirit_of_the_greater_wolf",
                SpellName = "Spirit of the Greater Wolf",
                Description = "Calls upon a greater wolf spirit to greatly increase movement speed.",
                GetIconFileName = getSoWIcon,
                Type = Spell.SpellType.Beneficial,
                Line = Spell.SpellLine.Global_Move,
                RequiredLevel = 25,
                ManaCost = 150,
                CastTime = 600f, // 10 seconds (60 ticks = 1 second)
                DurationTicks = 450, // 45 minutes (1 tick = 6 seconds)
                MovementSpeed = 3.5f,
                SelfOnly = false,
                SpellRange = 100f,
                ChargeFXIndex = 7,
                ResolveFXIndex = 7,
                StatusMessagePlayer = "You feel a greater wolf spirit empowering your stride.",
                StatusMessageNPC = " feels a greater wolf spirit.",
                GetClass = () => GameData.ClassDB?.Druid
            });

            // Spirit of the Elder Wolf (Level 35) - Ultimate movement speed buff
            SpellRegistry.RegisterSpell(new SpellRegistry.SpellDefinition
            {
                Id = "mds_spirit_of_the_elder_wolf",
                SpellName = "Spirit of the Elder Wolf",
                Description = "Calls upon an ancient elder wolf spirit for maximum movement speed.",
                GetIconFileName = getSoWIcon,
                Type = Spell.SpellType.Beneficial,
                Line = Spell.SpellLine.Global_Move,
                RequiredLevel = 35,
                ManaCost = 200,
                CastTime = 300f, // 5 seconds (60 ticks = 1 second)
                DurationTicks = 600, // 60 minutes (1 tick = 6 seconds)
                MovementSpeed = 5.0f,
                SelfOnly = false,
                SpellRange = 100f,
                ChargeFXIndex = 7,
                ResolveFXIndex = 7,
                StatusMessagePlayer = "You feel an ancient elder wolf spirit surge through you.",
                StatusMessageNPC = " feels an elder wolf spirit.",
                GetClass = () => GameData.ClassDB?.Druid
            });

            Debug.Log("MoarDruidSpells: All spell definitions registered.");
        }
    }

    /// <summary>
    /// Harmony patches to inject custom spells into the game's SpellDB.
    /// </summary>
    public static class DruidSpellsPatches
    {
        /// <summary>
        /// Patch SpellDB.Start() to inject custom spells after the database loads.
        /// </summary>
        [HarmonyPatch(typeof(SpellDB), "Start")]
        public class SpellDB_Start_Patch
        {
            private static void Postfix(SpellDB __instance)
            {
                Debug.Log("MoarDruidSpells: SpellDB.Start postfix - injecting custom spells...");

                // Initialize the spell registry (creates ScriptableObjects)
                SpellRegistry.Initialize();

                // Get our custom spells
                var customSpells = SpellRegistry.GetCreatedSpells();
                if (customSpells.Count == 0)
                {
                    Debug.Log("MoarDruidSpells: No custom spells to inject.");
                    return;
                }

                // Copy audio from vanilla spells before adding to database
                CopyVanillaAudio(customSpells, __instance.SpellDatabase);

                // Expand the SpellDatabase array to include our custom spells
                var originalSpells = __instance.SpellDatabase;
                var newSpellArray = new Spell[originalSpells.Length + customSpells.Count];

                // Copy original spells
                for (int i = 0; i < originalSpells.Length; i++)
                {
                    newSpellArray[i] = originalSpells[i];
                }

                // Add custom spells
                for (int i = 0; i < customSpells.Count; i++)
                {
                    newSpellArray[originalSpells.Length + i] = customSpells[i];
                    Debug.Log($"MoarDruidSpells: Added spell '{customSpells[i].SpellName}' to SpellDB");
                }

                // Replace the database array
                __instance.SpellDatabase = newSpellArray;

                Debug.Log($"MoarDruidSpells: SpellDB now contains {newSpellArray.Length} spells " +
                         $"({originalSpells.Length} original + {customSpells.Count} custom)");
            }

            /// <summary>
            /// Copy audio clips from similar vanilla spells to our custom spells.
            /// Matches by spell type and damage type to find appropriate sounds.
            /// </summary>
            private static void CopyVanillaAudio(List<Spell> customSpells, Spell[] vanillaSpells)
            {
                // Build lookup tables for vanilla spells by type
                var vanillaByType = new Dictionary<Spell.SpellType, List<Spell>>();
                foreach (var spell in vanillaSpells)
                {
                    if (spell == null) continue;
                    // Only consider spells that have audio
                    if (spell.ChargeSound == null && (spell.ChargeVariations == null || spell.ChargeVariations.Count == 0))
                        continue;

                    if (!vanillaByType.ContainsKey(spell.Type))
                        vanillaByType[spell.Type] = new List<Spell>();
                    vanillaByType[spell.Type].Add(spell);
                }

                foreach (var customSpell in customSpells)
                {
                    // Try to find a vanilla spell with matching type and damage type
                    Spell donor = FindBestAudioDonor(customSpell, vanillaByType);

                    if (donor != null)
                    {
                        // Copy audio properties
                        customSpell.ChargeSound = donor.ChargeSound;
                        customSpell.CompleteSound = donor.CompleteSound;

                        // Copy variation lists if they exist
                        if (donor.ChargeVariations != null && donor.ChargeVariations.Count > 0)
                        {
                            customSpell.ChargeVariations = new List<UnityEngine.AudioClip>(donor.ChargeVariations);
                        }
                        if (donor.CompleteVariations != null && donor.CompleteVariations.Count > 0)
                        {
                            customSpell.CompleteVariations = new List<UnityEngine.AudioClip>(donor.CompleteVariations);
                        }

                        Debug.Log($"MoarDruidSpells: Copied audio from '{donor.SpellName}' to '{customSpell.SpellName}'");
                    }
                    else
                    {
                        Debug.Log($"MoarDruidSpells: No audio donor found for '{customSpell.SpellName}' (Type: {customSpell.Type})");
                    }
                }
            }

            /// <summary>
            /// Find the best vanilla spell to copy audio from based on type and damage type.
            /// </summary>
            private static Spell FindBestAudioDonor(Spell customSpell, Dictionary<Spell.SpellType, List<Spell>> vanillaByType)
            {
                if (!vanillaByType.ContainsKey(customSpell.Type))
                    return null;

                var candidates = vanillaByType[customSpell.Type];

                // First pass: try to match damage type
                foreach (var candidate in candidates)
                {
                    if (candidate.MyDamageType == customSpell.MyDamageType)
                        return candidate;
                }

                // Second pass: just return first available of same type
                return candidates.Count > 0 ? candidates[0] : null;
            }
        }

        /// <summary>
        /// Patch PlayerControl.Start() to auto-learn all custom spells on character load.
        /// Spells are added directly to the player's spellbook if not already known.
        /// Only runs if AutoLearnSpells config option is enabled.
        /// </summary>
        [HarmonyPatch(typeof(PlayerControl), "Start")]
        public class PlayerControl_Start_Patch
        {
            private static void Postfix(PlayerControl __instance)
            {
                // Check if auto-learn is enabled in config
                if (Plugin.AutoLearnSpells?.Value != true)
                {
                    Debug.Log("MoarDruidSpells: Auto-learn disabled in config, skipping");
                    return;
                }

                var castSpell = __instance.GetComponent<CastSpell>();
                if (castSpell == null || castSpell.KnownSpells == null)
                {
                    Debug.LogWarning("MoarDruidSpells: Could not find CastSpell component on player");
                    return;
                }

                var customSpells = SpellRegistry.GetCreatedSpells();
                if (customSpells.Count == 0)
                {
                    Debug.Log("MoarDruidSpells: No custom spells to auto-learn");
                    return;
                }

                int learnedCount = 0;
                foreach (var spell in customSpells)
                {
                    // Check if spell is already known (by name to handle version changes)
                    bool alreadyKnown = false;
                    foreach (var knownSpell in castSpell.KnownSpells)
                    {
                        if (knownSpell != null && knownSpell.SpellName == spell.SpellName)
                        {
                            alreadyKnown = true;
                            break;
                        }
                    }

                    if (!alreadyKnown)
                    {
                        castSpell.KnownSpells.Add(spell);
                        learnedCount++;
                        Debug.Log($"MoarDruidSpells: Auto-learned spell '{spell.SpellName}'");
                    }
                }

                if (learnedCount > 0)
                {
                    Debug.Log($"MoarDruidSpells: Auto-learned {learnedCount} new spells");
                }
                else
                {
                    Debug.Log("MoarDruidSpells: All custom spells already known");
                }
            }
        }

        /// <summary>
        /// Patch SpellVessel.DoMiscSpells() to handle our custom Bind and Recall spells.
        /// Uses a prefix to intercept our spell names before the vanilla switch statement.
        /// </summary>
        [HarmonyPatch(typeof(SpellVessel), "DoMiscSpells")]
        public class SpellVessel_DoMiscSpells_Patch
        {
            private static bool Prefix(SpellVessel __instance)
            {
                // Access the spell field via reflection (it's public in SpellVessel)
                Spell spell = __instance.spell;
                if (spell == null)
                    return true;  // Let original method handle it

                switch (spell.SpellName)
                {
                    case "Bind":
                        HandleBindSpell();
                        return false;  // Skip original method

                    case "Recall":
                        HandleRecallSpell();
                        return false;  // Skip original method

                    default:
                        return true;  // Let original method handle other Misc spells
                }
            }

            /// <summary>
            /// Sets the player's respawn bind point to their current location.
            /// </summary>
            private static void HandleBindSpell()
            {
                // Get current scene and position
                string currentZone = SceneManager.GetActiveScene().name;
                Vector3 currentPos = GameData.PlayerControl.transform.position;
                bool usingSun = GameData.usingSun;

                // Set the bind point
                GameData.BindZone = currentZone;
                GameData.BindLoc = currentPos;
                GameData.SunInBindZone = usingSun;

                // Log messages
                UpdateSocialLog.LogAdd("You feel your spirit bind to this location.", "lightblue");
                UpdateSocialLog.LogAdd($"Bound to: {currentZone} ({currentPos.x:F1}, {currentPos.y:F1}, {currentPos.z:F1})", "grey");

                Debug.Log($"MoarDruidSpells: Bind set to {currentZone} at {currentPos}");
            }

            /// <summary>
            /// Teleports the player to their respawn bind location.
            /// </summary>
            private static void HandleRecallSpell()
            {
                // Check if bind location is set
                if (string.IsNullOrEmpty(GameData.BindZone))
                {
                    UpdateSocialLog.LogAdd("You have no bind point set!", "red");
                    return;
                }

                // Log the recall
                UpdateSocialLog.LogAdd("You feel yourself pulled toward your bind point...", "lightblue");

                // Save sim data before zone change (like other portal spells do)
                SimPlayerDataManager.SaveAllSimData();

                // Teleport to bind location (same as "Returning Wish" spell)
                GameData.SceneChange.ChangeScene(GameData.BindZone, GameData.BindLoc, GameData.SunInBindZone, 180f);

                Debug.Log($"MoarDruidSpells: Recall to {GameData.BindZone} at {GameData.BindLoc}");
            }
        }
    }
}

