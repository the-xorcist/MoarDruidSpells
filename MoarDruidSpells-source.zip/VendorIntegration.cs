using System.Collections.Generic;
using HarmonyLib;
using UnityEngine;

namespace MoarDruidSpells
{
    /// <summary>
    /// Adds custom druid spell scrolls to the Druid vendor Tiver Banes in Port Azure.
    /// Spell scrolls are Items with TeachSpell set to our custom spells.
    /// </summary>
    public static class VendorIntegration
    {
        private static List<Item> _spellScrolls = new List<Item>();
        private static bool _initialized = false;

        /// <summary>
        /// Creates spell scroll Items for each custom spell.
        /// Must be called after SpellRegistry.Initialize().
        /// </summary>
        public static void Initialize()
        {
            if (_initialized) return;
            _initialized = true;

            foreach (var spell in SpellRegistry.GetCreatedSpells())
            {
                var scroll = CreateSpellScroll(spell);
                if (scroll != null)
                {
                    _spellScrolls.Add(scroll);
                    Debug.Log($"[MoarDruidSpells] Created spell scroll: '{scroll.ItemName}' for spell '{spell.SpellName}'");
                }
            }

            Debug.Log($"[MoarDruidSpells] VendorIntegration initialized with {_spellScrolls.Count} spell scrolls");
        }

        private static Sprite _spellScrollIcon;

        /// <summary>
        /// Finds the icon used by existing druid spell scrolls in the game.
        /// </summary>
        private static Sprite GetSpellScrollIcon()
        {
            if (_spellScrollIcon != null) return _spellScrollIcon;

            if (GameData.ItemDB?.ItemDB != null)
            {
                // Look for known druid spell scrolls by name pattern
                foreach (var item in GameData.ItemDB.ItemDB)
                {
                    if (item != null && item.TeachSpell != null && item.ItemIcon != null)
                    {
                        if (item.name.Contains("Biting Vines") ||
                            item.name.Contains("DruDD") ||
                            item.name.Contains("Summon Forest"))
                        {
                            _spellScrollIcon = item.ItemIcon;
                            Plugin.Instance.Logger.LogInfo($"[VendorIntegration] Copied sprite from existing druid scroll: {item.ItemName}");
                            return _spellScrollIcon;
                        }
                    }
                }

                // Fallback: any spell scroll with the "8" icon that's 512x512
                foreach (var item in GameData.ItemDB.ItemDB)
                {
                    if (item != null && item.TeachSpell != null && item.ItemIcon != null)
                    {
                        if (item.ItemIcon.name == "8" &&
                            item.ItemIcon.rect.width == 512 &&
                            item.ItemIcon.rect.height == 512)
                        {
                            _spellScrollIcon = item.ItemIcon;
                            Plugin.Instance.Logger.LogInfo($"[VendorIntegration] Copied 512x512 sprite from: {item.ItemName}");
                            return _spellScrollIcon;
                        }
                    }
                }
            }

            Plugin.Instance.Logger.LogWarning("[VendorIntegration] Could not find existing druid spell scroll icon");
            return null;
        }

        /// <summary>
        /// Creates a spell scroll Item that teaches the given spell.
        /// </summary>
        private static Item CreateSpellScroll(Spell spell)
        {
            if (spell == null) return null;

            var scroll = ScriptableObject.CreateInstance<Item>();
            scroll.name = $"SPELL SCROLL - {spell.SpellName}";
            scroll.Id = $"moardruidspells_{spell.SpellName.ToLower().Replace(" ", "_")}_scroll";
            scroll.ItemName = $"Spell Scroll: {spell.SpellName}";
            scroll.RequiredSlot = Item.SlotType.General;
            scroll.TeachSpell = spell;

            // Price based on spell level (1000 gold per level, minimum 1000)
            scroll.ItemValue = Mathf.Max(1000, spell.RequiredLevel * 1000);

            scroll.Classes = new System.Collections.Generic.List<Class>();
            scroll.Lore = $"This scroll teaches the spell: {spell.SpellName}\n\n{spell.SpellDesc}";
            scroll.ItemIcon = GetSpellScrollIcon();
            scroll.Unique = false;
            scroll.Stackable = false;

            return scroll;
        }

        /// <summary>
        /// Gets all created spell scrolls.
        /// </summary>
        public static List<Item> GetSpellScrolls()
        {
            return _spellScrolls;
        }
    }

    /// <summary>
    /// Harmony patch to add spell scrolls to Tiver Banes' vendor inventory.
    /// DISABLED: Spell scrolls not yet implemented - spells are auto-learned on login.
    /// </summary>
    // [HarmonyPatch(typeof(VendorInventory), "Start")]
    public class VendorInventory_Start_Patch
    {
        private static readonly HashSet<int> _patchedVendors = new HashSet<int>();

        private static void Postfix(VendorInventory __instance)
        {
            string npcName = __instance.transform.name;

            if (!npcName.Contains("Tiver Banes"))
                return;

            int instanceId = __instance.GetInstanceID();
            if (_patchedVendors.Contains(instanceId))
            {
                Debug.Log($"[MoarDruidSpells] Tiver Banes (instance {instanceId}) already patched, skipping");
                return;
            }

            VendorIntegration.Initialize();

            var scrolls = VendorIntegration.GetSpellScrolls();
            if (scrolls.Count == 0)
            {
                Debug.Log($"[MoarDruidSpells] Found Tiver Banes but no spell scrolls to add");
                return;
            }

            int addedCount = 0;
            foreach (var scroll in scrolls)
            {
                bool alreadyHasScroll = false;
                foreach (var existingItem in __instance.ItemsForSale)
                {
                    if (existingItem != null && existingItem.Id == scroll.Id)
                    {
                        alreadyHasScroll = true;
                        break;
                    }
                }

                if (!alreadyHasScroll)
                {
                    __instance.ItemsForSale.Add(scroll);
                    addedCount++;
                    Debug.Log($"[MoarDruidSpells] Added '{scroll.ItemName}' to Tiver Banes' inventory");
                }
            }

            _patchedVendors.Add(instanceId);

            Debug.Log($"[MoarDruidSpells] Added {addedCount} spell scrolls to Tiver Banes (instance {instanceId})");
        }
    }
}

