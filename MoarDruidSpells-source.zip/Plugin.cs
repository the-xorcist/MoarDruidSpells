using BepInEx;
using BepInEx.Configuration;
using BepInEx.Logging;
using HarmonyLib;
using UnityEngine;

namespace MoarDruidSpells
{
    [BepInPlugin("the-xorcist.moardruidspells", "Moar Druid Spells", "1.0.0")]
    public class Plugin : BaseUnityPlugin
    {
        public static Plugin Instance { get; private set; }

        /// <summary>
        /// Expose logger for other classes to use.
        /// </summary>
        public new ManualLogSource Logger => base.Logger;

        // =======================================================================
        // Configuration
        // =======================================================================

        /// <summary>
        /// If true, all custom spells are automatically added to the player's
        /// spellbook on character login. If false, spells must be obtained
        /// through other means (e.g., vendors, quests).
        /// </summary>
        public static ConfigEntry<bool> AutoLearnSpells;

        /// <summary>
        /// If true, use the classic/original SoW icon. If false, use the new icon.
        /// </summary>
        public static ConfigEntry<bool> UseClassicSoWIcon;

        // =======================================================================
        // SimPlayer SoW Request Behavior
        // =======================================================================

        /// <summary>
        /// Enable SimPlayers to request Spirit of the Wolf buffs via whisper/shout.
        /// </summary>
        public static ConfigEntry<bool> EnableSoWRequests;

        /// <summary>
        /// Base chance per tick (6 seconds) for a SimPlayer to request SoW via whisper.
        /// Modified by zone size, dungeon status, and group status.
        /// </summary>
        public static ConfigEntry<float> SoWWhisperBaseChance;

        /// <summary>
        /// Base chance per tick for a SimPlayer to shout for SoW in zone chat.
        /// Modified by zone size, dungeon status, and group status.
        /// </summary>
        public static ConfigEntry<float> SoWShoutBaseChance;

        /// <summary>
        /// If true, automatically learn the vanilla portal spells (Portal to Hidden,
        /// Portal to Braxonian, etc.) on character login.
        /// </summary>
        public static ConfigEntry<bool> LearnPortalSpells;

        private void Awake()
        {
            Instance = this;
            Logger.LogInfo("MoarDruidSpells: Initializing...");

            // Bind config entries - Spells
            AutoLearnSpells = Config.Bind(
                "Spells",
                "AutoLearnSpells",
                true,
                "Automatically add all custom druid spells to your spellbook on character login.");

            UseClassicSoWIcon = Config.Bind(
                "Spells",
                "UseClassicSoWIcon",
                false,
                "Use the classic Spirit of the Wolf icon instead of the new one.");

            // Bind config entries - SimPlayer SoW Requests
            EnableSoWRequests = Config.Bind(
                "SimPlayer SoW Requests",
                "EnableSoWRequests",
                true,
                "Enable SimPlayers to request Spirit of the Wolf buffs via whisper and shout.");

            SoWWhisperBaseChance = Config.Bind(
                "SimPlayer SoW Requests",
                "WhisperBaseChance",
                0.5f,
                new ConfigDescription(
                    "Base chance (%) per tick for a lone SimPlayer to whisper you for SoW. " +
                    "Reduced in dungeons and when grouped. Set to 0 to disable whispers.",
                    new AcceptableValueRange<float>(0f, 10f)));

            SoWShoutBaseChance = Config.Bind(
                "SimPlayer SoW Requests",
                "ShoutBaseChance",
                0.2f,
                new ConfigDescription(
                    "Base chance (%) per tick for a lone SimPlayer to shout for SoW in zone chat. " +
                    "Reduced in dungeons and when grouped. Set to 0 to disable shouts.",
                    new AcceptableValueRange<float>(0f, 10f)));

            // Bind config entries - Portal Spells
            LearnPortalSpells = Config.Bind(
                "Spells",
                "LearnPortalSpells",
                true,
                "Automatically learn the vanilla portal spells (Portal to Hidden, Portal to Braxonian, etc.) " +
                "on character login. These spells will also have their range fixed to work from anywhere.");

            // Register all spell definitions (before SpellDB.Start runs)
            DruidSpells.RegisterAllSpells();

            // Apply Harmony patches:
            // - SpellDB_Start_Patch: injects custom spells into SpellDB
            // - PlayerControl_Start_Patch: auto-learns spells (if enabled), learns portal spells (if enabled)
            // - SpellVessel_DoMiscSpells_Patch: handles Bind/Recall spells
            // - CastSpell_StartSpell_Patch: fixes portal spell range
            Harmony harmony = new Harmony("the-xorcist.moardruidspells");
            harmony.PatchAll();

            Logger.LogInfo("MoarDruidSpells: Plugin loaded.");
        }
    }
}

