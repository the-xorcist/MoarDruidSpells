using System;
using System.Collections.Generic;
using System.IO;
using System.Reflection;
using UnityEngine;

namespace MoarDruidSpells
{
    /// <summary>
    /// Manages registration and creation of custom Druid spells.
    /// Add new spells by calling RegisterSpell() with a SpellDefinition.
    /// </summary>
    public static class SpellRegistry
    {
        private static readonly List<SpellDefinition> _spellDefinitions = new List<SpellDefinition>();
        private static readonly List<Spell> _createdSpells = new List<Spell>();
        private static bool _initialized = false;
        private static string _modPath;

        /// <summary>
        /// Definition for a custom spell - supports all spell types (damage, heal, DoT, buff, debuff)
        /// </summary>
        public class SpellDefinition
        {
            // Basic identity
            public string Id { get; set; }
            public string SpellName { get; set; }
            public string Description { get; set; }
            public string IconFileName { get; set; }

            /// <summary>
            /// Optional: Dynamic icon filename getter. If set, this takes precedence over IconFileName.
            /// Useful for config-driven icon selection.
            /// </summary>
            public Func<string> GetIconFileName { get; set; }

            // Classification
            public Spell.SpellType Type { get; set; } = Spell.SpellType.Beneficial;
            public Spell.SpellLine Line { get; set; } = Spell.SpellLine.Generic;
            public GameData.DamageType DamageType { get; set; } = GameData.DamageType.Magic;

            // Requirements
            public int RequiredLevel { get; set; } = 1;
            public int ManaCost { get; set; } = 10;

            // Casting
            public float CastTime { get; set; } = 3f;  // In ticks (60 ticks = 1 second)
            public float Cooldown { get; set; } = 0f;  // Cooldown in seconds
            public float SpellRange { get; set; } = 100f;
            public bool SelfOnly { get; set; } = false;

            // Effects
            public int HP { get; set; } = 0;  // Max HP modifier (stat buff/debuff, NOT damage/healing)
            public int TargetDamage { get; set; } = 0;  // Direct damage AND DoT damage per tick
            public int TargetHealing { get; set; } = 0;  // Healing per tick for HoT spells
            public int DurationTicks { get; set; } = 0;  // 1 tick = 6 seconds for status effects
            public float MovementSpeed { get; set; } = 0f;
            public bool RootTarget { get; set; } = false;
            public float Haste { get; set; } = 0f;
            public int Aggro { get; set; } = 0;
            public bool UnstableDuration { get; set; } = false;
            public bool BreakOnDamage { get; set; } = false;

            // Stat buffs/debuffs
            public int AC { get; set; } = 0;
            public int Str { get; set; } = 0;
            public int End { get; set; } = 0;
            public int Dex { get; set; } = 0;
            public int Agi { get; set; } = 0;
            public int Int { get; set; } = 0;
            public int Wis { get; set; } = 0;
            public int Cha { get; set; } = 0;
            public int MR { get; set; } = 0;
            public int ER { get; set; } = 0;
            public int PR { get; set; } = 0;
            public int VR { get; set; } = 0;
            public int DamageShield { get; set; } = 0;
            public float PercentLifesteal { get; set; } = 0f;
            public int AtkRollModifier { get; set; } = 0;
            public int BleedDamagePercent { get; set; } = 0;

            // Visual/Audio FX
            public int ChargeFXIndex { get; set; } = 0;
            public int ResolveFXIndex { get; set; } = 0;

            // Special flags
            public bool WornEffect { get; set; } = false;  // If true, treats HoT like equipment regen (no wisdom scaling, no combat log)

            // Messages
            public string StatusMessagePlayer { get; set; } = "";
            public string StatusMessageNPC { get; set; } = "";

            // SimPlayer usage
            public bool SimUsable { get; set; } = true;

            // Class restriction
            public Func<Class> GetClass { get; set; }
        }

        /// <summary>
        /// Register a new spell definition. Call this before Initialize().
        /// </summary>
        public static void RegisterSpell(SpellDefinition definition)
        {
            _spellDefinitions.Add(definition);
            Debug.Log($"SpellRegistry: Registered spell definition: {definition.SpellName}");
        }

        /// <summary>
        /// Initialize and create all registered spells. Call after databases are loaded.
        /// </summary>
        public static void Initialize()
        {
            if (_initialized) return;

            _modPath = Path.GetDirectoryName(Assembly.GetExecutingAssembly().Location);

            foreach (var def in _spellDefinitions)
            {
                try
                {
                    var spell = CreateSpell(def);
                    if (spell != null)
                    {
                        _createdSpells.Add(spell);
                        Debug.Log($"SpellRegistry: Created spell: {spell.SpellName}");
                    }
                }
                catch (Exception ex)
                {
                    Debug.LogError($"SpellRegistry: Failed to create spell {def.SpellName}: {ex}");
                }
            }

            _initialized = true;
            Debug.Log($"SpellRegistry: Initialized with {_createdSpells.Count} spells");
        }

        /// <summary>
        /// Get all created spells for injection into SpellDB
        /// </summary>
        public static List<Spell> GetCreatedSpells() => _createdSpells;

        private static Spell CreateSpell(SpellDefinition def)
        {
            var spell = ScriptableObject.CreateInstance<Spell>();

            // ALWAYS set the Unity ScriptableObject name (required for UnityExplorer and internal lookups)
            spell.name = def.Id;

            // Also set the Id property via reflection (inherited from BaseScriptableObject)
            var idField = typeof(Spell).BaseType?.GetField("Id", BindingFlags.Public | BindingFlags.Instance);
            if (idField != null)
                idField.SetValue(spell, def.Id);

            // Basic properties
            spell.SpellName = def.SpellName;
            spell.SpellDesc = def.Description;
            spell.Type = def.Type;
            spell.Line = def.Line;
            spell.MyDamageType = def.DamageType;
            spell.RequiredLevel = def.RequiredLevel;
            spell.ManaCost = def.ManaCost;
            spell.SpellChargeTime = def.CastTime;
            spell.Cooldown = def.Cooldown;
            spell.SpellRange = def.SpellRange;
            spell.SelfOnly = def.SelfOnly;
            spell.HP = def.HP;
            spell.TargetDamage = def.TargetDamage;
            spell.TargetHealing = def.TargetHealing;
            spell.SpellDurationInTicks = def.DurationTicks;
            spell.MovementSpeed = def.MovementSpeed;
            spell.RootTarget = def.RootTarget;
            spell.Haste = def.Haste;
            spell.Aggro = def.Aggro;
            spell.UnstableDuration = def.UnstableDuration;
            spell.BreakOnDamage = def.BreakOnDamage;

            // Stat modifiers
            spell.AC = def.AC;
            spell.Str = def.Str;
            spell.End = def.End;
            spell.Dex = def.Dex;
            spell.Agi = def.Agi;
            spell.Int = def.Int;
            spell.Wis = def.Wis;
            spell.Cha = def.Cha;
            spell.MR = def.MR;
            spell.ER = def.ER;
            spell.PR = def.PR;
            spell.VR = def.VR;
            spell.DamageShield = def.DamageShield;
            spell.percentLifesteal = def.PercentLifesteal;
            spell.AtkRollModifier = def.AtkRollModifier;
            spell.BleedDamagePercent = def.BleedDamagePercent;

            // FX
            spell.SpellChargeFXIndex = def.ChargeFXIndex;
            spell.SpellResolveFXIndex = def.ResolveFXIndex;

            // Special flags
            spell.WornEffect = def.WornEffect;

            // Messages
            spell.StatusEffectMessageOnPlayer = def.StatusMessagePlayer;
            spell.StatusEffectMessageOnNPC = def.StatusMessageNPC;

            // SimPlayer usage
            spell.SimUsable = def.SimUsable;

            // Set class restriction
            spell.UsedBy = new List<Class>();
            if (def.GetClass != null)
            {
                var classRef = def.GetClass();
                if (classRef != null)
                    spell.UsedBy.Add(classRef);
            }

            // Load icon from assets folder (use dynamic getter if available)
            string iconFileName = def.GetIconFileName?.Invoke() ?? def.IconFileName;
            spell.SpellIcon = LoadIcon(iconFileName);

            // Initialize audio clip lists (required to avoid NullReferenceException)
            spell.ChargeVariations = new List<AudioClip>();
            spell.CompleteVariations = new List<AudioClip>();

            return spell;
        }

        private static Sprite LoadIcon(string fileName)
        {
            if (string.IsNullOrEmpty(fileName)) return null;

            string iconPath = Path.Combine(_modPath, "Assets", fileName);
            if (!File.Exists(iconPath))
            {
                Debug.LogWarning($"SpellRegistry: Icon not found: {iconPath}");
                return null;
            }

            byte[] data = File.ReadAllBytes(iconPath);
            var texture = new Texture2D(2, 2);
            ImageConversion.LoadImage(texture, data);

            return Sprite.Create(texture, new Rect(0, 0, texture.width, texture.height),
                new Vector2(0.5f, 0.5f), 100f);
        }
    }
}

